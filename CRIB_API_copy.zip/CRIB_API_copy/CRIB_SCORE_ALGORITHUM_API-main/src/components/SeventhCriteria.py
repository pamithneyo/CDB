import os
import sys
from src.logger import logging
from src.exception import CustomException
import pandas as pd
from dataclasses import dataclass
import numpy as np

class SeventhCriteria:
    def __init__(self,crib_status:pd.DataFrame,credit_facillities:pd.DataFrame):
        
        self.credit_facillities = credit_facillities
        self.crib_status = crib_status


    def calculate_seventh_score(self):

        logging.info("Entered the calculate seventh criteria score calculation")
        
        try:
            filtered = self.credit_facillities[self.credit_facillities['OWNERSHIP'] == 'As Borrower']

            if not filtered.empty:

                total_granted_amount_y1 = filtered['YEAR_1_TOT_AMOUNT_GRANTED'].sum()
                total_granted_amount_y2 = filtered['YEAR_2_TOT_AMOUNT_GRANTED'].sum()

                facility_amount = self.crib_status['FACILITY_AMOUNT']
                total_granted_amount =total_granted_amount_y1+total_granted_amount_y2
                score = (total_granted_amount/facility_amount)*100

                # Extract the scalar value from the Series
                score_value = score.values[0]

                # Assuming 'score' is a column in your DataFrame
                if score_value >= 100:
                    crib_sc = 1
                elif 50 <= score_value < 100:
                    crib_sc = 0.5
                elif 0 < score_value <= 50:
                    crib_sc = 0.1
                else:
                    crib_sc = 0.1

                score=crib_sc*0.05*100

            else:
                score=1*0.05*100
        
            return(
                score
            )
        except Exception as e:
            raise CustomException(e,sys)
        

