import os
import pandas as pd
from glob import glob
from src.logger import logging
from src.exception import CustomException
from src.utils import dataColumnsCheck

from src.components.FirstCriteria import FirstCriteria
from src.components.SecondCriteria import SecondCriteria
from src.components.ThirdCriteria import ThirdCriteria
from src.components.FouthCriteria import FouthCriteria
from src.components.FifthCriteria import FifthCriteria
from src.components.SixthCriteria import SixthCriteria
from src.components.SeventhCriteria import SeventhCriteria
from src.components.EighthCriteria import EighthCriteria
from src.components.NinethCriteria import NinethCriteria
from src.components.TenthCriteria import TenthCriteria

data_folder = 'Data2'

def run_pipeline():
    
    # Initialize an empty dataframe to store the results
    results_df = pd.DataFrame()

    if dataColumnsCheck():
    
        # Iterate over all subfolders in the 'Data' folder
        for subfolder in os.listdir(data_folder):
            # Define the path to the subfolder
            subfolder_path = os.path.join(data_folder, subfolder)
            
            # Check if the path is a directory
            if os.path.isdir(subfolder_path):
                # Get a list of all csv files in the subfolder
                csv_files = glob(os.path.join(subfolder_path, '*.csv'))
                
                
                # Check if there are 7 csv files in the subfolder
                if len(csv_files) == 7:
                    # Load the csv files into dataframes
                    crib_status = pd.read_csv(csv_files[0])
                    credit_facility = pd.read_csv(csv_files[1])
                    facility_detail = pd.read_csv(csv_files[2])
                    crib_dishouner = pd.read_csv(csv_files[3])
                    lending_inf = pd.read_csv(csv_files[4])
                    current_liabilities = pd.read_csv(csv_files[5])
                    credit_facillities = pd.read_csv(csv_files[6])
                    
                    
                    # Run the pipeline and get the scores
                    # Note: You need to define the classes and functions used in the pipeline
                    tenth_score = TenthCriteria(crib_status, facility_detail).calculate_tenth_score()
                    nineth_score = NinethCriteria(crib_status, facility_detail).calculate_nineth_score()
                    eight_score = EighthCriteria(crib_dishouner).calculate_eighth_score()
                    seventh_score = SeventhCriteria(crib_status, credit_facillities).calculate_seventh_score()
                    six_score = SixthCriteria(crib_status, current_liabilities).calculate_sixth_score()
                    # fifth_score = FifthCriteria(lending_inf, facility_detail).calculate_fifth_score()
                    fouth_score = FouthCriteria(current_liabilities, facility_detail).calculate_fouth_score()
                    third_score = ThirdCriteria(crib_status, credit_facility, facility_detail).calculate_third_score()
                    second_score = SecondCriteria(crib_status, credit_facility, facility_detail).calculate_second_score()
                    first_score = FirstCriteria(crib_status, credit_facility, facility_detail).calculate_first_score()
                    
                    # total_score=float(tenth_score)+float(nineth_score)+float(eight_score)+float(seventh_score)+float(six_score)+float(fifth_score)+float(fouth_score)+float(third_score)+float(second_score)+float(first_score)
                    
                    # Create a dictionary with the scores and the folder name
                    result = {
                        'folder_name': subfolder,
                        'tenth_score': tenth_score,
                        'nineth_score': nineth_score,
                        'eight_score': eight_score,
                        'seventh_score': seventh_score,
                        'six_score': six_score,
                        # 'fifth_score': fifth_score,
                        'fouth_score': fouth_score,
                        'third_score': third_score,
                        'second_score': second_score,
                        'first_score': first_score,
                        # 'total_score':total_score
                    }
                    
                    # Append the result to the results dataframe
                    results_df = results_df.append(result, ignore_index=True)
                    
        print(results_df)
        results_df.to_csv("dataset_final_new.csv")        
    else:
        logging.info("dataset columns mismatched")
        print("dataset columns mismatched....")
  
if __name__=="__main__":
    run_pipeline()
