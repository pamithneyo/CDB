data_path: str=os.path.join('artifacts',"813204592V","CDB_CDPU_CRIB_STATUS.csv")
data_path1: str=os.path.join('artifacts',"813204592V","CRIB_24M_CREDIT_FAC.csv")
data_path2: str=os.path.join('artifacts',"813204592V","CRIB_CREDIT_FAC_DTL.csv")

crib_status = pd.read_csv(data_path)
credit_facility = pd.read_csv(data_path1)
facility_detail = pd.read_csv(data_path2)





# crib_status = pd.read_excel(data_path, sheet_name='CDB_CDPU_CRIB_STATUS')
    # credit_facility = pd.read_excel(data_path, sheet_name='CRIB_24M_CREDIT_FAC')
    # facility_detail = pd.read_excel(data_path, sheet_name='CRIB_CREDIT_FAC_DTL')
    # current_liabilities = pd.read_excel(data_path, sheet_name='POTENTIAL_CURRENT_LIABILITIES')
    # lending_inf = pd.read_excel(data_path, sheet_name='CRIB_INQ_MADE_6M_LENDING_INS')
    # credit_facillities = pd.read_excel(data_path, sheet_name='CRIB_SETTLED_CREDIT_FACILITIES')
    

    # crib_dishouner = pd.read_excel(data_path1, sheet_name='CRIB_DISHONOUR_CHQ_DTLS')
    # crib_status_1 = pd.read_excel(data_path1, sheet_name='CDB_CDPU_CRIB_STATUS')
    # facility_detail_1 = pd.read_excel(data_path1, sheet_name='CRIB_CREDIT_FAC_DTL')


    # if __name__=="__main__":
#     start_time = time.time()

#     obj=ThirdCriteria()
#     first_score=obj.calculate_third_score()

#     end_time = time.time()
#     execution_time = end_time - start_time

#     print('------------')
#     print(f"Third Criteria Score Value : {first_score}")
#     print('---------')
#     print(f"Execution time: {execution_time} seconds")
  