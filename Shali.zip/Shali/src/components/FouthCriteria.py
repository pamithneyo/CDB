import os
import sys
from src.logger import logging
from src.exception import CustomException
import pandas as pd
from dataclasses import dataclass
import numpy as np
import time


class FouthCriteria:
    def __init__(self,current_liabilities:pd.DataFrame,facility_detail:pd.DataFrame):

        self.data_path: str=os.path.join('artifacts',"testing01_0437453.xlsx")

        self.cf_stat = ['ACTV', 'LGAL', 'TRMN', 'RSTR', 'R&SL', 'WRTN', 'MGCP']
        self.own_shp = ['GRT','001','JNT']
        self.cf_type = ['OVDR']
        self.output_data = []

        self.current_liabilities = current_liabilities
        self.credit_facility_detail = facility_detail

    def get_assigned_values(self,row):
        cf_status = row['CF_Stat']
        own_shp_status = row['Own_Shp']
        cf_type_value = row['CF_Type']
        id = row['Running_NIC']

        if cf_status in self.cf_stat and own_shp_status in self.own_shp:
            if cf_type_value in self.cf_type:
                # If CF_Type is OVDR, get the value from the Current_Balance column
                self.output_data.append({'RUNNING_NIC': id, 'Amount_Granted_Limit': row['Current_Balance']})
            else:
                # If CF_Type is not OVDR, get the value from the Amount_Granted_Limit column
                self.output_data.append({'RUNNING_NIC': id, 'Amount_Granted_Limit': row['Amount_Granted_Limit']})

        else:
            self.output_data.append({'RUNNING_NIC':"999", 'Amount_Granted_Limit': 999})

            
    def calculate_fouth_score(self):

        logging.info("Entered the calculate fouth criteria score calculation")
        
        try:
            # Example usage with the sample DataFrame
            self.credit_facility_detail.apply(self.get_assigned_values, axis=1)

            # Convert the list of dictionaries to a DataFrame
            output_df = pd.DataFrame(self.output_data)

            # Display the resulting DataFrame
            fillterID = output_df.RUNNING_NIC.unique()

            # Filtering df2 based on output_df['No']
            filtered_df2 = self.current_liabilities[self.current_liabilities['RUNNING_NIC'].isin(fillterID)]
            # # Filtering df3 based on output_df['No']
            # filtered_df3 = self.credit_facility_detail[self.credit_facility_detail['Running_NIC'].isin(fillterID)]

            if not filtered_df2.empty:

                result = filtered_df2.groupby(['OWNERSHIP'])['TOT_AMOUNT_GRANTED'].sum().reset_index()

                # Calculate sums for 'As Borrower' and 'As Guarantor'
                sum_as_borrower = result[result.OWNERSHIP == 'As Borrower'].TOT_AMOUNT_GRANTED.sum()
                sum_as_guarantor = result[result.OWNERSHIP == 'As Guarantor'].TOT_AMOUNT_GRANTED.sum()

                # Check for division by zero
                if sum_as_borrower == 0:
                    ratio = 100  # or handle the case appropriately
                else:
                    # Calculate the ratio
                    ratio = (sum_as_guarantor / sum_as_borrower)
                print(ratio) 
                if ratio <= 0.5:
                    crib04 = 1
                elif 0.5 < ratio < 0.75:
                    crib04 = 0.5
                elif 0.75 < ratio < 1:
                    crib04 = 0
                else:
                    crib04 = -0.25

                score=crib04*0.05*100
            
            else:
                score=1*0.05*100
            print(filtered_df2)
            if (self.current_liabilities.empty) & ( self.credit_facility_detail.empty) :
                score =0
            return(
                score
            )
        except Exception as e:
            raise CustomException(e,sys)
        


  