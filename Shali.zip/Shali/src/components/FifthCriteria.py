import os
import sys
from src.logger import logging
from src.exception import CustomException
import pandas as pd
from dataclasses import dataclass
import numpy as np
from datetime import datetime, timedelta,date
import time


class FifthCriteria:
    def __init__(self,lending_inf:pd.DataFrame,facility_detail:pd.DataFrame):

        self.lending_inf = lending_inf
        self.credit_facility_detail = facility_detail


    def calculate_fifth_score(self):

        logging.info("Entered the calculate fifth criteria score calculation")
        
        try:
           # Step 1: Convert 'Inquiry_Date' to datetime format and remove timezone
            self.lending_inf['Inquiry_Date'] = self.lending_inf['Inquiry_Date']
            self.lending_inf['Inquiry_Date'] = pd.to_datetime(self.lending_inf['Inquiry_Date'],format='%d/%m/%Y')
            # .dt.tz_localize(None)
            # self.lending_inf['Inquiry_Date'] = pd.to_datetime(self.lending_inf['Inquiry_Date'])
            # Step 2: Get the Current Date
            current_date = datetime.now()

            # Step 3: Calculate Six Months Ago
            six_months_ago = current_date - pd.DateOffset(days=180)

            # Make sure six_months_ago is timezone-naive
            # six_months_ago = six_months_ago.tz_localize(None)

            print("six month ago")

            print(six_months_ago)

            print("Inquiry_Date")
            print(self.lending_inf['Inquiry_Date'])
            
            # Step 4: Filter the Dataset
            df5 = self.lending_inf[self.lending_inf['Inquiry_Date'] >= six_months_ago]

            print("filtered date")

            print(df5)
            df5['Reason_lower'] = df5['Reason'].str.lower()
            
            if not df5.empty:
                current_date = date.today()

                # Assuming 'Inquiry_Date' is in a datetime format in your DataFrame
                # df5['Inquiry_Date'] = pd.to_datetime(df5['Inquiry_Date'])
                df5['Inquiry_Date'] = pd.to_datetime(df5['Inquiry_Date'])
                df5 = df5.sort_values(by='Inquiry_Date', ascending=False)
                print(df5['Inquiry_Date']) 

                # Get the current date
                current_date = datetime.now()
                # Calculate the difference in days
                df5['Days_Since_Inquiry'] = (current_date - df5['Inquiry_Date']).dt.days

                print(df5['Days_Since_Inquiry'] )

                # Add a new column with the date after one month
                df5['One_month_After'] = df5['Inquiry_Date'] + timedelta(days=30)

    

                # Convert "First_Disburse_Date" to datetime format if it's not already
                self.credit_facility_detail['First_Disburse_Date'] = pd.to_datetime(self.credit_facility_detail['First_Disburse_Date'])

                print(self.credit_facility_detail['First_Disburse_Date'])

                # Extract the date part and repeat it for each row
                self.credit_facility_detail['Disburse_Date_Only'] = self.credit_facility_detail['First_Disburse_Date'].dt.strftime('%Y-%m-%d')
                self.credit_facility_detail['Disburse_Date_Only'] =pd.to_datetime(self.credit_facility_detail['Disburse_Date_Only'])
                self.credit_facility_detail = self.credit_facility_detail.sort_values(by='Disburse_Date_Only', ascending=False)
                
                print(self.credit_facility_detail['Disburse_Date_Only'] )

                # # Add a new column with the date after one week
                df5['One_month_After'] = df5['Inquiry_Date'] + timedelta(days=30)
                df5['One_month_After'] = pd.to_datetime(df5['One_month_After']).dt.strftime('%Y-%m-%d')

                df5['One_month_After'] = pd.to_datetime(df5['One_month_After'],format='%Y-%m-%d')
                df5 = df5.sort_values(by='One_month_After', ascending=False)
                print(df5['One_month_After'])

                # Create a new column in df5 and initialize it with 0
                df5['flag1'] = 0

                # Iterate through each row in df5
                for index, row in df5.iterrows():
                    # Check if 'Disburse_Date_Only' is between 'Inquiry_Date' and 'One_Week_After'
                    if any((self.credit_facility_detail['Disburse_Date_Only'] >= row['Inquiry_Date']) & 
                        (self.credit_facility_detail['Disburse_Date_Only']<= row['One_month_After'])&(row['Reason_lower'] == 'evaluating of a borrower for a new credit facility')):
                        print("called")
                        df5.at[index, 'flag1'] = 1
                    df5['Mark'] = df5.apply(lambda row: 1 if row['flag1'] == 1 and row['Reason_lower'] == 'evaluating of a borrower for a new credit facility' else 0, axis=1)

                # Check if there is any value of -0.5 in the 'Mark' column
                if (0 in df5['Mark'].values) &('evaluating of a borrower for a new credit facility' in df5['Reason_lower'].values):
                    final_score =-0.5*0.05*100
                else:
                    final_score = 1* 0.05*100

            else:
                final_score=1* 0.05*100

            return(
                final_score
            )
        except Exception as e:
            raise CustomException(e,sys)
        



  