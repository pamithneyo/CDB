
def dataColumnsCheck():
    return True