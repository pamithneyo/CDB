from flask import Flask,request,jsonify
import os


excel_file_path = 'testing01_0437453.xlsx'

app = Flask(__name__)


@app.route('/', methods=['GET'])
def index():
    app.logger.info("call the main route")
    response = jsonify({
        "message": f"use predict route to get predictions",
    })
    response.status_code = 200
    return response

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8443))
    app.run(host='0.0.0.0', port=port)    
